var customer = require('../models/customer');

//Get Methods
module.exports = function (req, res, next) {

    

};
